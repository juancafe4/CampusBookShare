package com.polybookshare.master.campusbookshare;

import android.graphics.Bitmap;
import android.media.Image;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.Request;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Profile extends Fragment {
    private String cookie = "";
    private String picture_url = "";
    protected TextView email;
    protected TextView phone;
    protected TextView userName;
    protected TextView info;
    protected TextView upVotes;
    protected TextView virals;
    private ImageView m_profilePicture;


    /*public Profile(String ck) {
        this.cookie = ck;
        Log.d("cookie page", cookie);
    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.cookie = getArguments().getString("cookies");
        View profile = inflater.inflate(R.layout.activity_profile, container, false);

        initLayout(profile);
        showProfile(profile);
        Log.d("picture url", "response" + picture_url);
        return profile;
    }

    public void initLayout(View view) {
        //setContentView(R.layout.activity_profile);
        email = (TextView) view.findViewById(R.id.email);
        phone = (TextView) view.findViewById(R.id.phoneNumber);
        userName = (TextView) view.findViewById(R.id.names);
        info = (TextView) view.findViewById(R.id.info);
        upVotes = (TextView) view.findViewById(R.id.upVotes);
        virals = (TextView) view.findViewById(R.id.virals);

        virals.setText(virals.getText() + "\n");
    }

    private void showProfile(View view) {
        String url = "http://192.168.43.162:8080/auth/me";
        final View myView = view;
        Log.d("show profile", cookie);
        RequestQueue queue = Volley.newRequestQueue(getActivity());
        JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, url , null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            String temp = (String) virals.getText();
                            picture_url = (String) response.get("picture_url");
                            getImage(myView);
                            //Log.d("name", "name " + userName.getText());
                            userName.setText((String) response.get("name"));
                            email.setText((String) response.get("email"));
                            info.setText((String) response.get("bio"));
                            phone.setText((String) response.get("phone"));
                            JSONArray codes = (JSONArray) response.get("virals");
                            Log.d("codes", (String) codes.get(0));
                            for (int i = 0; i < codes.length(); i++)
                                //Log.d("codes", (String) codes.get(i));
                                temp += "\n" + codes.get(i);
                            upVotes.setText(String.valueOf(response.get("votes")));
                            virals.setText(temp);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.e("Error: ", error.getMessage());
                Log.d("error64", "error getting user");
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> headers = new HashMap<String, String>();
                headers.put("Cookie", cookie);
                return headers;
            }
        };

        queue.add(req);
    }

    private void getImage(View view) {
        Log.d("url pic", picture_url);
        m_profilePicture = (ImageView) view.findViewById(R.id.profile_picture);
        Picasso.with(getActivity())
                .load(picture_url)
                .resize(350, 350)
                .centerCrop()
                .into(m_profilePicture);
    }
}

