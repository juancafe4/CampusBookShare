package com.polybookshare.master.campusbookshare;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;


public class HomeActivity extends Fragment {
    private ArrayList<Klass> m_klasses;
    private KlassAdapter m_adapter;


    protected Button recenttBooks;
    protected Button recentKlasses;
    protected Button searchBooks;
    protected Button searchKlasses;

    private String cookie = "";
    @Override
    public void onCreate(Bundle saveOnInstance) {
        super.onCreate(saveOnInstance);

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_home, container, false);

        this.cookie = getArguments().getString("cookies");
        initLayout(view);
        addListenners(view);
        return view;
    }


    public void initLayout(View view) {
        recenttBooks = (Button) view.findViewById(R.id.go_recent_books);
        recentKlasses = (Button) view.findViewById(R.id.go_recent_klasses);
        searchBooks = (Button) view.findViewById(R.id.search_books);
        searchKlasses = (Button) view.findViewById(R.id.search_klasses);
    }

    public void addListenners(View view) {
        recenttBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("before call", "before recent");
                Intent i = new Intent(getActivity(), BookRecentActivity.class);
                i.putExtra("cookie", cookie);
                startActivity(i);

            }
        });

        recentKlasses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("before call", "before recent");
                Intent i = new Intent(getActivity(), KlassRecentActivity.class);
                i.putExtra("cookie", cookie);
                startActivity(i);
            }
        });
    }

}
