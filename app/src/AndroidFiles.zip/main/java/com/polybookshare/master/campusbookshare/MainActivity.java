package com.polybookshare.master.campusbookshare;

import android.app.DownloadManager;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.android.volley.RequestQueue;
import android.util.Base64;
import com.android.volley.*;
import android.provider.SyncStateContract.Constants;
import android.util.Log;
import android.content.Intent;
import org.apache.http.params.HttpConnectionParams;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import android.support.v7.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;

import org.json.JSONException;
public class MainActivity extends AppCompatActivity {

    private int status = -1;
    private RequestQueue queue;
    private String user_id = "";
    private String cookie = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        queue = Volley.newRequestQueue(this);
        login();
    }

    private void login() {
        Log.d("login", "here");
        String url = "http://192.168.43.162:8080/auth/login";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        Log.d("response32", "response " + response);
                        //user_id = response.substring(8, response.length() - 2);
                        showProfile();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Log.d("error log in ", String.valueOf(error.networkResponse.statusCode));
                NetworkResponse networkResponse = error.networkResponse;

                if (error.networkResponse == null) {
                    Log.d("throw error", error.getClass().toString());
                    if (error.getClass().equals(NoConnectionError.class)) {
                        // Show timeout error message
                        Toast.makeText(getBaseContext(),
                                "Sorry Cannot Connect this time",
                                Toast.LENGTH_LONG).show();
                    }
                }

                if (networkResponse != null && networkResponse.statusCode == 401) {
                    // HTTP Status Code: 401 Unauthorized
                    status = networkResponse.statusCode;
                    Log.d("error64", String.valueOf( networkResponse.statusCode));

                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog.setTitle("HTTP 401");
                    alertDialog.setMessage("Wrong email or password");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }

            }
        })  {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                //add params <key,value>
                params.put("email", "ferrel@calpoly.edu");
                params.put("password", "4481257Phone");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> headers = new HashMap<String, String>();
                // add headers <key,value>
                String credentials = "ferrel@calpoly.edu" +":"+ "4481257Phone";
                String auth = "Basic "
                        + Base64.encodeToString(credentials.getBytes(),
                        Base64.NO_WRAP);
                headers.put("Content-Type", "application/x-www-form-urlencoded");
                headers.put("Authorization", auth);
                return headers;
            }

            @Override
            protected Response parseNetworkResponse(NetworkResponse response) {
                Map headers = response.headers;
                Log.d("status32", "status " + response.statusCode);
                Log.d("headers32", (String) headers.get("Set-Cookie"));
                cookie = (String) headers.get("Set-Cookie");
                //Preferences.getInstance().saveCookie(cookie);
                return super.parseNetworkResponse(response);

            }
        };
        // Add the request to the RequestQueue.
        Log.d("end of login", stringRequest.toString());
        queue.add(stringRequest);

    }

    private void showProfile() {
        //Intent i = new Intent(getApplicationContext(), Profile.class);
        Intent i = new Intent(getApplicationContext(), HomeTab.class);
        i.putExtra("cookie", cookie);
        startActivity(i);
    }
}
