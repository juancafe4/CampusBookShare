package com.polybookshare.master.campusbookshare;

import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentActivity;

import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.View;


public class HomeTab extends FragmentActivity{

    protected String cookie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        cookie = new String("");
        cookie =  getIntent().getStringExtra("cookie");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_tab);
        View home = getLayoutInflater().inflate(R.layout.home, null);
        View classes = getLayoutInflater().inflate(R.layout.classes, null);
        View bookshelf = getLayoutInflater().inflate(R.layout.bookshelf, null);
        View info = getLayoutInflater().inflate(R.layout.info, null);
        View profile = getLayoutInflater().inflate(R.layout.profile, null);
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);

        tabLayout.addTab(tabLayout.newTab().setCustomView(home));
        tabLayout.addTab(tabLayout.newTab().setCustomView(bookshelf));
        tabLayout.addTab(tabLayout.newTab().setCustomView(classes));
        tabLayout.addTab(tabLayout.newTab().setCustomView(profile));
        tabLayout.addTab(tabLayout.newTab().setCustomView(info));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter
                (getSupportFragmentManager(), tabLayout.getTabCount(), cookie);
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        viewPager.setCurrentItem(0, false);
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

}
